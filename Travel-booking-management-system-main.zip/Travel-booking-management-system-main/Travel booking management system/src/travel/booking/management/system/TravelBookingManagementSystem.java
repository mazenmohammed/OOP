
package travel.booking.management.system;


public class TravelBookingManagementSystem {

    
    public static void main(String[] args) {
       GUI f= new GUI();
    }
    
}
